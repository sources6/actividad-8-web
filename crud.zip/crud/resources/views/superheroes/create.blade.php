<div>
@extends('layouts.app')

@section('content')
    <h1>Crear nuevo superhéroe</h1>

    <form action="{{ route('superheroes.store') }}" method="POST">
        @csrf

        <div class="form-group">
            <label for="nombre_real">Nombre real</label>
            <input type="text" class="form-control" id="nombre_real" name="nombre_real" value="{{ old('nombre_real') }}">
        </div>

        <div class="form-group">
            <label for="nombre_heroe">Nombre de superhéroe</label>
            <input type="text" class="form-control" id="nombre_heroe" name="nombre_heroe" value="{{ old('nombre_heroe') }}">
        </div>

        <div class="form-group">
            <label for="foto">Foto</label>
            <input type="text" class="form-control" id="foto" name="foto" value="{{ old('foto') }}">
        </div>

        <div class="form-group">
            <label for="informacion_adicional">Información adicional</label>
            <textarea class="form-control" id="informacion_adicional" name="informacion_adicional" rows="3">{{ old('informacion_adicional') }}</textarea>
        </div>

        <button type="submit" class="btn btn-primary">Crear</button>
    </form>
@endsection

</div>
