<div>
@extends('layouts.app')

@section('content')
    <h1>Lista de superhéroes</h1>

    <table class="table">
        <thead>
            <tr>
                <th>Nombre real</th>
                <th>Nombre de superhéroe</th>
                <th>Foto</th>
                <th>Información adicional</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($superheroes as $superheroe)
                <tr>
                    <td>{{ $superheroe->nombre_real }}</td>
                    <td>{{ $superheroe->nombre_heroe }}</td>
                    <td><img src="{{ $superheroe->foto }}" width="100" /></td>
                    <td>{{ $superheroe->informacion_adicional }}</td>
                    <td>
                        <a href="{{ route('superheroes.show', $superheroe) }}">Ver</a>
                        <a href="{{ route('superheroes.edit', $superheroe) }}">Editar</a>
                        <form action="{{ route('superheroes.destroy', $superheroe) }}" method="POST">
                            @csrf
                            @method('DELETE')
                            <button type="submit">Eliminar</button>
                        </form>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>

    <a href="{{ route('superheroes.create') }}">Crear nuevo superhéroe</a>
@endsection

</div>
