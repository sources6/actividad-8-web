<div>
@extends('layouts.app')

@section('content')
    <h1>Superhéroe: {{ $superheroe->nombre_heroe }}</h1>

    <ul>
        <li>Nombre real: {{ $superheroe->nombre_real }}</li>
        <li>Nombre de superhéroe: {{ $superheroe->nombre_heroe }}</li>
        <li><img src="{{ $superheroe->foto }}" width="200" /></li>
        <li>Información adicional: {{ $superheroe->informacion_adicional }}</li>
    </ul>

    <a href="{{ route('superheroes.edit', $superheroe) }}">Editar</a>
@endsection

</div>
