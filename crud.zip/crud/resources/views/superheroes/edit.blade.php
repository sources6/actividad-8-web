<div>
@extends('layouts.app')

@section('content')
    <h1>Editar superhéroe: {{ $superheroe->nombre_heroe }}</h1>

    <form action="{{ route('superheroes.update', $superheroe) }}" method="POST">
        @csrf
        @method

</div>
