<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Superheroe extends Model
{
    protected $fillable = [
        'nombre_real',
        'nombre_heroe',
        'foto',
        'informacion_adicional',
    ];
}
